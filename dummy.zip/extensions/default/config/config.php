<?php
$config = <<<EOD
{
	"wizards": []
}
EOD;
;?>
