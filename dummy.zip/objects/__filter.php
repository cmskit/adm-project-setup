<?php
$stringified_filter = <<<EOD
{}
EOD;
$filter = json_decode($stringified_filter, true);
