<?php
	// empty cms-kit data-model
	$objects = json_decode('{}');
?>
