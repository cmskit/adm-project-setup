<?php
$model = <<<EOD
{"objects":{}}
EOD;
?>
