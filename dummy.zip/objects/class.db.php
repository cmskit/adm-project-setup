<?php/*autoload dummy*/include_once __DIR__ . '/__database.php';
