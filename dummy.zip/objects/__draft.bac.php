<?php
$model = <<<'EOD'
{
  "object": []
}
EOD;
?>
